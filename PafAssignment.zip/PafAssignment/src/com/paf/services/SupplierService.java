package com.paf.services;

import com.paf.model.Supplier;

public interface SupplierService {

	public void addSupplier(Supplier supplier);
	
	
	public void updateSupplier(Supplier suppier);
	
	
	
	public void deleteSupplier(int supplierId);
	
	public void readSupplier();
	
	
	
	public String getHTMLTableReport();
	
	public void getSupplier(int supplierId);
	
	public Supplier getSupplier();

}
